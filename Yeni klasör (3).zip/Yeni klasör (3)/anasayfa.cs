﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace parlalıgecis
{

    public partial class anasayfa : Form
    {
        private static Random random = new Random();
        private int shift;

        public anasayfa()
        {
            InitializeComponent();
        }
        OleDbConnection baglanti =new OleDbConnection(" ");
        private string Encrypt(string text, int shift)
        {
            char[] buffer = text.ToCharArray();

            for (int i = 0; i < buffer.Length; i++)
            {
                char letter = buffer[i];

                // Büyük harfse
                if (char.IsUpper(letter))
                {
                    letter = (char)(letter + shift);

                    if (letter > 'Z')
                    {
                        letter = (char)(letter - 26);
                    }
                    else if (letter < 'A')
                    {
                        letter = (char)(letter + 26);
                    }
                }
                // Küçük harfse
                else if (char.IsLower(letter))
                {
                    letter = (char)(letter + shift);

                    if (letter > 'z')
                    {
                        letter = (char)(letter - 26);
                    }
                    else if (letter < 'a')
                    {
                        letter = (char)(letter + 26);
                    }
                }

                buffer[i] = letter;
            }

            return new string(buffer);
        }

        // Metni verilen kaydırma miktarı ile çözer
        private string Decrypt(string text, int shift)
        {
            return Encrypt(text, -shift);
        }

        private void anasayfa_FormClosed(object sender, FormClosedEventArgs e)
        {
           Application.Exit();  
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            string originalMessage = txtOriginalMessage.Text;
            shift = random.Next(1, 26); // 1 ile 25 arasında rastgele bir kaydırma miktarı seçer
            string encryptedMessage = Encrypt(originalMessage, shift);
            txtEncryptedMessage.Text = encryptedMessage;
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            string encryptedMessage = txtEncryptedMessage.Text;
            string decryptedMessage = Decrypt(encryptedMessage, shift);
            txtDecryptedMessage.Text = decryptedMessage;
        }

        private void txtOriginalMessage_TextChanged(object sender, EventArgs e)
        {
             
        }
    }
}
